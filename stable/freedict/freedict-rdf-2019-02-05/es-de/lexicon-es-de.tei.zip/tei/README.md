This is the Spanish-German dictionary from
<http://cvs.savannah.gnu.org/viewvc/*checkout*/ding-es-de/ding-es-de/es-de>.
The copyright is (c) Zeno Gantner <es-de@zenogantner.de>, Matthias Buchmeier, and others 2003-2012

It has been auto-imported with the Ding2tei FreeDict importer. For license
information, please see the TEI source header or the file COPYING.

