This is the Esperanto-English dictionary by Paul Denisowski. The importer for
the FreeDict project has been written by Sebastian Humenda.

For instructions on how to build and install this dictionary, see the file
[INSTALL](INSTALL).

License
-------

The dictionary is (C) 2015 Paul Denisowski nder the terms of the Creative
Commons Unported 3.0 license. See the file COPYING for the licensing details.

The GPL-licensed importer can be found as part of the FreeDict tools release.
